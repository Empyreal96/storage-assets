# Windows Server 2003 (NT 5.2 / 3790) guide
*Version 9c, last updated 2020/10/27*

Build guide tested under XP SP3 x86, Win7 SP1 x86/x64 & Win10 x64, results may vary under other operating systems.

## Build Preparations
---

- **Ensure build machine date is current** - there's no longer any need to set date to 2003 or anything.
- Extract source tree to a folder named `srv03rtm` on the root of a drive (**important, as pre-built DirectUI files will only link properly under this path**), drive letter doesn't seem to matter, use `D:\srv03rtm\` as the path to match RTM binaries.
- Unset Read-only on extracted directory (including subfolders and files)
- Copy over files from this ZIP into source tree, overwriting existing files as necessary
- **If using a 64-bit host OS to build with:** copy the contents of the ZIPs `_x64` folder into the source tree, overwriting if asked.
- Create desktop shortcut for `%windir%\system32\cmd.exe /k D:\srv03rtm\tools\razzle.cmd free offline` (see below for explanation) and change `Start in` to `D:\srv03rtm`
- **If using 64-bit host OS** use `razzle64.cmd` in the shortcut instead of `razzle.cmd`
- Open razzle window using shortcut you created (run shortcut as admin if your OS uses UAC!)
- Finally run `tools\prebuild.cmd` to finish preparing your build environment (only need to run once after initing razzle for first time in this tree)

You can also start razzle by running `tools\razzle{64}.cmd free offline` from an elevated command-prompt inside the source folder.

If you use an AV or your OS has one built in (Windows Defender etc) make sure to disable them before extracting / starting the build.  
(both of those actions generate a ton of new files, and your AV will try scanning every single one, disabling them beforehand will make the build go quite a bit faster.)  
This also counts for applications like voidtools' Everything!  

## Building
---

### Clean build

Performs clean rebuild of all components (**recommended for first build!**):

  - `build /cZP` (`bcz` is also aliased to this)

### "Dirty" build

Builds only components that have changed since last clean build:

  - `build /ZP` (`bz` is also aliased to this)

### Post-build

  - Extract [2k3-missing-x86fre.7z](https://gofile.io/d/N7trJu) into your `binaries.x86fre` folder (`binaries.x86fre` will be created during the build), should contain files for all SKUs (uses pidgen.dll from Win2003 Standard, so your builds should accept Standard product keys)
  - **When asked during extraction to overwrite folders select `Yes`, but when asked to overwrite files like DUser.pdb/dll make sure to select `No`!**
  - Once missing files have been added, you should have files such as `binaries.x86fre\_pop3_00.htm`, `binaries.x86fre\ql10wnt.sys`, etc.
  - Inside the razzle window run `tools\postbuild.cmd` (use `-sku:{sku}` if you want to process only specific one (no brackets!), expect `filechk` errors if you ignore this and didn't use missing.7z / missing.cmd with every sku)

Once postbuild has finished, assuming you used the `2k3-missing-x86fre.7z` file above and followed the guide properly, it should have hopefully succeeded without errors, and there shouldn't be any `binaries.x86fre\build_logs\postbuild.err` file!

Otherwise take a look inside the `postbuild.err` - most messages in here are negligible, but if you see `filechk` errors associated with the edition you want to use, you may need to re-run `missing.cmd`, or extract `2k3-missing.7z` again.

If `postbuild.err` contains messages like `(crypto.cmd) ERROR` or `(ntsign.cmd) ERROR` try re-importing the `tools\driver.pfx` key-file (double-click it, press Next through the prompts, password is empty), and make sure your system date is set to the current date (updated certs are only valid from October 2020 to October 2021)

If postbuild.err has filechk errors about missing `hwcomp.dat` files, try copying the following into a batch script and run it in a razzle prompt (after using postbuild once already):

```
@echo off
hwdatgen -i:%_NTPOSTBLD%\pro\i386 -o:%_NTPOSTBLD%\.\hwcomp.dat
hwdatgen -i:%_NTPOSTBLD%\per\i386 -o:%_NTPOSTBLD%\perinf\hwcomp.dat
hwdatgen -i:%_NTPOSTBLD%\bla\i386 -o:%_NTPOSTBLD%\blainf\hwcomp.dat
hwdatgen -i:%_NTPOSTBLD%\sbs\i386 -o:%_NTPOSTBLD%\sbsinf\hwcomp.dat
hwdatgen -i:%_NTPOSTBLD%\srv\i386 -o:%_NTPOSTBLD%\srvinf\hwcomp.dat
hwdatgen -i:%_NTPOSTBLD%\ads\i386 -o:%_NTPOSTBLD%\entinf\hwcomp.dat
```

### Creating bootable ISO files

  - Execute `tools\oscdimg.cmd {sku} [destination-file (optional)]` where `{sku}` is one of: 
    - `srv` - Windows Server 2003 Standard Edition
    - `sbs` - Windows Server 2003 Small Business Edition
    - `ads` - Windows Server 2003 Enterprise Edition
    - `dtc` - Windows Server 2003 Datacenter Edition
    - `bla` - Windows Server 2003 Web Edition
    - `per` - Windows XP Home Edition
    - `pro` - Windows XP Professional
  - ISO will be saved to `{build-drive}\{build-tag}_{sku}.iso`, unless `[destination-file]` is provided as a parameter.

## Additional Info
---

### prepatched\.zip additions list
- New unexpired test-signing certificates (valid to October 2021 - tools\openssl.txt describes how to generate them)
- Updated `midl.exe`/`midlc.exe` from Win2003 SP1 DDK, fixes olepro32.dll errors
- Reordered `dirs` file to ensure that `conlibk.lib` is built before it gets used
- parse.cpp/parse.hpp files required to build DirectUI.lib, and the bison.exe/Bison.skl files used to generate them.
- Pre-compiled parse.obj file, as the parse.cpp/parse.hpp mentioned above has some issues parsing things.. (parse.obj taken from win2003 directuid.lib - causes LNK4206 warnings when using it though, suppressed via changes to `sources` files)
- Pre-compiled GdiPlus v1.0.100.0 from RTM ISO, to be included into `asms01.cab` (x86 only), as the GdiPlus code sadly can't be built.
- Updated DUser build scripts, to make sure it gets placed in the proper location & gets built with the right optimization flags.
- Updated `windows\advcore\dirs` file to allow DUser/DirectUI to get built during main build
- Updated 16-bit build tools inside com\ole32\olethunk\ole16\tools\, and updated olethunk code so it'll build fine with them. (updates are only used if OS requires them to build, XP/2003 should be able to build them fine without changes)
- Disabled fixprn.pl, ntbackuponpersonal.cmd, gpmc.cmd, msi.cmd & incbbt.cmd calls from pbuild.dat, as we're missing required build-files for those (you can grab the results of those scripts from RTM ISO, or from the `2k3-missing-x86fre.7z` pack)
- Updated `setupw95.cmd` & `drivercab.cmd` to add a delay between async calls, fixes an issue with filename-collisions. (update only needed under newer OS's, older OS's like XP don't seem to have this issue)
- Updated `razzle.cmd` to always set `__BUILDMACHINE__` variable, allows build tag built into kernel to match with BuildName.txt (and won't leak your build OS username into the build-tag any more)
- Updated `razzle.cmd` to always set `NO_PDB_PATHS=1`, the build already uses FixPdbPaths.exe to remove file-paths from PDB, but that method leaves null-characters in place which aren't in the retail files, may as well enable this since there's no reason not to.
- Updated `ixsso` makefile, to prevent MIDL2346 warning from breaking the build (warning seems locale related, for some reason `BUILD_ALLOW_MIDL_WARNINGS` only worked when defined inside makefile, pretty strange)
- Reordered `windows\appcompat\dirs` file to help with single-core builds (from idkwhy's OpenXP git repo)
- Updated `msitoddf.cpp`, now closes the MSI package handle when finished (prevents stalling postbuild on Win10), and added fix for 64-bit build OS (redirects SysWOW64 to System32)
- Updated `mshtml.ref` reference file - used to compare mshtml output against known-good one? last updated in 1999(!), without updating it seems to randomly cause build error in certain conditions (I'm not sure why we never had problems with this until we tried 64-bit stuff though...)
- [x64] Added 32-bit mapsym.exe & rc.bat MSDOS-Player wrapper to `printscan\faxsrv\print\faxprint\faxdrv\win9x\sdk\binw16` dir, since some anons seemed to get errors from this folder.
- [x64] Replaced `masm.exe/mkpublic.exe` with 32-bit versions (taken from Sizzle), as some anons had issues with MS-DOS Player reporting a bad DOS version, breaking those two tools as they require DOS 2.0+
- `razzle64.cmd` which can take care of converting 16-bit tools to 32-bit (via `MS-DOS Player`), and setting required environment variables before launching razzle.
- `prebuild.cmd` that can handle installing driver.pfx keys, fixing file attributes, removing updated files if OS doesn't require them, and copying GdiPlus SxS policies.
- `missing.cmd` that can copy files we don't have source for from a mounted ISO.
- `oscdimg.cmd` to generate an ISO image from a finished post-build.

### x64 build OS support
prepatched\.zip v9 adds support for using x64 build OS's such as Win10 x64, this is done by wrapping certain 16-bit tools using `MS-DOS Player`, using .bat files to redirect calls to use the player, changing some makefiles to use 32-bit equivalents, etc.

Unfortunately some of the wrapped 16-bit tools can still randomly error without rhyme or reason for it, as a workaround the .bat files of the worst offenders will give it 3 attempts before failing, hopefully this should be enough to allow builds to complete fine, but there's still a chance one of the other 16-bit tools could error too... maybe in future I'll apply this 3-attempts bandaid over all the 16-bit tools.

### Timebomb

- Time can be adjusted by editing `DAYS` variable inside `\tools\postbuildscripts\timebomb.cmd` (line 44)
- Setting `DAYS` to `0` will disable the timebomb.
- Only certain `DAYS` parameters are valid (0, 5, 15, 30, 60, 90, 120, 150, 180, 240, 360, 444)

### Different build options

You can modify your razzle shortcut (or execute it manually inside your source folder) to include (or remove) additional argument(s):

- `free` - build 'free' bits (production, omitting it will generated checked bits)
- `chkkernel` - build 'checked' (testing) kernel/hal/ntdll when building 'free' bits
- `no_opts` - disable binary optimization (useful for debugging, but will most likely fail a full build, some code can't be built without optimization)
- `verbose` - enable verbose output of the build process
- `binaries_dir <basepath>` - specifies custom output directory (default is `binaries`, the suffix added after `.` is non-customizable)

Other options are not described here, see `razzle.cmd /?` for details.

### Creating fresh postbuild

- `tools\postbuild.cmd -full`
- `tools\missing.cmd`
- `tools\postbuild.cmd`

Use `-sku:{sku}` if you want to process only specific one (no brackets!)

### Building specific components

Most components can be built seperately. For example, if you wish to rebuild `ntos` component, perform these steps:
 - `cd base\ntos` (you can also use `ntos` alias that razzle has set up for you)
 - `bcz` (alias for `build /cPZ`)

Generally `postbuild.cmd` is clever enough to include your changes properly without needing fresh build as it uses `bindiff` to find differences.

### Generating new build number/name

Version information is stored in `\public\sdk\inc\ntverp.h`

You can also use `m0 set_builddate set_buildnum set_buildname` to generate new build name quickly.

### Original CD filenames

- `5.2.3790.0.srv03_rtm.030324-2048_x86fre_server-standard_retail_en-us-NRMSFPP_EN.iso` (SHA1: A600409482A5678EF6AF2B26D3576D6D9894178D)
- `5.2.3790.0.srv03_rtm.030324-2048_x86fre_server-datacenter_retail_en-us-NRMDOEM_EN.iso` (SHA1: E2B47A7CE45C6C6305594CEE4C1B64894805AAF4)
- `5.2.3790.0.srv03_rtm.030324-2048_x86fre_server-enterpriseserver_retail_en-us-NRMEFPP_EN.iso` (SHA1: 0309FFB4181BA5122C692A6E1079E9FC1D53FCE4)
- `5.2.3790.0.srv03_rtm.030324-2048_x86fre_server-webserver_retail_en-us-NRMWFPP_EN.iso` (SHA1: 46C1CCB2CFC96803E304A35BEF50CD71B2C1DE38)
- `5.1.2600.0.xpclient.010817-1148_x86fre_client-home_retail_en-us-WXHFPP_EN.iso` (SHA1: B273C8D41E3844E3E46722F52F5A4CF9F206C8D0)
- `5.1.2600.0.xpclient.010817-1148_x86fre_client-professional_retail_en-us-WXPFPP_EN.iso` (SHA1: 1400DED4402D50F3864ED3D8DCF5CC52BA79A04A)
- `sbs.iso` (converted from mdf; SHA1: CDB30C80FDE314C16CA11F5CD31650ECBEC7A214)

### Product keys

- Standard Edition: M6RJ9-TBJH3-9DDXM-4VX9Q-K8M8M
- Enterprise Edition: QW32K-48T2T-3D2PJ-DXBWY-C6WRJ

## Changelog
---

Each major release will likely break dirty builds, requiring a fresh clean-build, it's recommended to apply new releases onto newly extracted source code if possible.

###### v9
- (v9c) [x64] Added 32-bit mapsym.exe & rc.bat MSDOS-Player wrapper to `printscan\faxsrv\print\faxprint\faxdrv\win9x\sdk\binw16` dir, since some anons seemed to get errors from this folder.
- (v9b) [x64] Replaced `masm.exe/mkpublic.exe` with 32-bit versions (taken from Sizzle), as some anons had issues with MS-DOS Player reporting a bad DOS version, breaking those two tools as they require DOS 2.0+ - thanks to the anon from the thread who helped test!
- 64-bit builder support: added `_x64` subdirectory containing fixed files, & `razzle64.cmd` for building under 64-bit hosts (tested under Win7SP1 x64 & Win10 x64)
- Updated razzle.cmd to set `NO_PDB_PATHS=1` without needing officialbuild parameter (reasoning in the additions list above)
- Fix `ixsso` build error by adding `BUILD_ALLOW_MIDL_WARNINGS=1` to makefile, stops MIDL2346 warning from breaking the build (warning seems to be caused by using a non-US locale? can this be fixed via parameters, or a locale-emulator?)
- Reorder `windows\appcompat\dirs` file to help with single-core builds (from idkwhy's OpenXP git repo)
- Updated `msitoddf.cpp`, now closes the MSI package handle when finished (prevents stalling postbuild on Win10), and added fix for 64-bit build OS (redirects SysWOW64 to System32)
- Updated `mshtml.ref` reference file - used to compare mshtml output against known-good one? last updated in 1999(!), without updating it seems to randomly cause build error in certain conditions (only started appearing on win10 though, never had them on win7/XP...)

###### v8
- (v8d) Revert `srv_info.chm` changes, as an anon managed to find that inside an XP x64 ISO image, now included inside `2k3-missing-x86fre-v7.7z`
- (v8d) Updated `cddirs.lst` to allow `valueadd\3rdparty` folder to be included into the CD image.
- (v8c) Updated razzle.cmd to always set `__BUILDMACHINE__` variable regardless of "offline" parameter, allows build tag built into kernel to match BuildName.txt
- **Note: the razzle.cmd change above will require clean-building afterwards! If you want to continue 'dirty'-building with your current build make sure you don't extract the updated razzle.cmd from this pack**
- (v8c) Made oscdimg.cmd use build tag from BuildName.txt as output filename if destination path isn't provided
- (v8c) Removed directui_XP.lib file, as our built directui.lib seems to work fine
- (v8b) Added pre-built parse.obj files for DirectUI, taken from win2003 directuid.lib - allows us to build a working version of DirectUI fine!
- (v8b) Updated `shell\cpls\appwzdui\winnt\sources`, `shell\ext\logondui\sources` & `shell\shell32\winnt\sources` files to suppress LNK4206 warning generated by pre-built parse.obj.
- (v8b) Deleted all references to `srv_info.chm` (which can't be located anywhere, no RTM ISOs seem to have it), may as well remove it so it can't mess up any more builds.
- (v8b) Updated `setupw95.cmd` & `drivercab.cmd` to add a delay between async calls, fixes an issue with filename-collisions. (update only needed under newer OS's, older OS's like XP don't seem to have this issue)
- (v8b) Updated `windows\advcore\dirs` file to allow DUser/DirectUI to get built during main build
- (v8a) Disabled incbbt.cmd from pbuild.dat, as the incbbt.cmd file is missing
- Updated 16-bit build tools inside com\ole32\olethunk\ole16\tools\, and updated olethunk code so it'll build fine with them.
- Removed pre-built 16-bit code
- Updated prebuild.cmd to handle the updated 16-bit tools instead of using pre-built stuff (will only use updated files if OS requires them)
- Disabled fixprn.pl, ntbackuponpersonal.cmd, gpmc.cmd and msi.cmd calls from pbuild.dat, as we're missing required build-files for those (you can grab the results of those scripts from RTM ISO, or from the `2k3-missing-x86fre.7z` pack)
- Thanks to anon who made `2k3-missing-x86fre`, we should now be able to build without any postbuild errors!

###### v7
- (7e) removed DUser/DirectUI building instructions, readded DUser.dll to missing.cmd - sadly our built one doesn't work properly and breaks `pro` sku's login screen. Likely because of Bison.skl being customized by MS, which was missing from the source code.
- (7d) removed DUser.dll from missing.cmd
- (7c) changed DUser placefil.txt so DUser.dll gets placed in binaries.x86fre root
- (7c) updated DUser bldenv.cmd so that 'bldenv release' will also reset optimization flags, now release builds will get proper optimization
- includes Win7 fixes from guideanon's v4 toolkit, hopefully reduces NTVDM errors for people
- adds files & instructions for building DUser.dll/DirectUI.lib, can now build a proper server2003 version of it instead of needing the WinXP one
- adds pre-built GdiPlus 1.0.100.0, since we can't build GdiPlus code atm (should allow building a working `asms01.cab`/`hivesxs.inf`)
- removed `asms01.cab`/`hivesxs.inf` from missing.cmd
- moved prebuild to `tools\prebuild.cmd`, no longer deletes itself afterwards in case it needs to be ran again
- re-ordered some of the build preparation steps, added details about building `DirectUI.lib` before the main build
